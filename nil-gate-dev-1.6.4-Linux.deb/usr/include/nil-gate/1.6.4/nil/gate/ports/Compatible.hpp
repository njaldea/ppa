#pragma once

#include "../detail/Port.hpp"
#include "../errors.hpp"
#include "../ports/External.hpp"
#include "../ports/ReadOnly.hpp"
#include "../traits/compatibility.hpp"

namespace nil::gate
{
    class INode;
}

namespace nil::gate::concepts
{
    template <typename TO, typename FROM>
    concept is_compatible = requires(TO to, FROM from) {
        { traits::compatibility<TO, FROM>::convert(from) };
    };
}

namespace nil::gate::errors
{
    template <typename TO, typename FROM>
    struct Compatibility
    {
        Error compatibility = Check<concepts::is_compatible<TO, FROM>>("Not Compatible");
    };
}

namespace nil::gate::ports
{
    template <typename TO>
    class Compatible final
    {
    public:
        Compatible() = delete;

        template <typename FROM>
            requires(!concepts::is_compatible<TO, FROM> && !std::is_same_v<TO, FROM>)
        // NOLINTNEXTLINE(hicpp-explicit-conversions)
        Compatible(ports::ReadOnly<FROM>* /*port*/)
            : Compatible(errors::Compatibility<TO, FROM>())
        {
        }

        template <typename FROM>
            requires(concepts::is_compatible<TO, FROM> && !std::is_same_v<TO, FROM>)
        // NOLINTNEXTLINE(hicpp-explicit-conversions)
        Compatible(ports::ReadOnly<FROM>* port)
            : Compatible(static_cast<detail::Port<FROM>*>(port)->template adapt<TO>())
        {
        }

        template <typename FROM>
            requires(concepts::is_compatible<TO, FROM> && !std::is_same_v<TO, FROM>)
        // NOLINTNEXTLINE(hicpp-explicit-conversions)
        Compatible(External<FROM>* port)
            : Compatible(port->to_direct())
        {
        }

        // NOLINTNEXTLINE(hicpp-explicit-conversions)
        Compatible(ports::ReadOnly<TO>* port)
            : context(port)
            , ptr_attach_out(&impl_attach_out<detail::Port<TO>>)
            , ptr_detach_out(&impl_detach_out<detail::Port<TO>>)
            , ptr_is_ready(&impl_is_ready<detail::Port<TO>>)
            , ptr_score(&impl_score<detail::Port<TO>>)
            , ptr_value(&impl_value<detail::Port<TO>>)
        {
        }

        // NOLINTNEXTLINE(hicpp-explicit-conversions)
        Compatible(External<TO>* port)
            : Compatible(port->to_direct())
        {
        }

        ~Compatible() noexcept = default;

        Compatible(Compatible&&) noexcept = default;
        Compatible& operator=(Compatible&&) noexcept = default;

        Compatible(const Compatible&) = default;
        Compatible& operator=(const Compatible&) = default;

        template <typename T>
        Compatible& operator=(ports::ReadOnly<T>* port)
        {
            auto* p = parent;
            *this = Compatible<TO>(port);
            static_cast<detail::Port<T>*>(port)->attach_out(p);
            return *this;
        }

        template <typename T>
        Compatible& operator=(External<T>* port)
        {
            *this = port->to_compat();
            return *this;
        }

        const TO& value() const
        {
            // should not be possible based on how it is called
            return ptr_value(context);
        }

        void attach_out(INode* node)
        {
            parent = node;
            if (nullptr == context)
            {
                return;
            }
            ptr_attach_out(context, node);
        }

        void detach_out(INode* node)
        {
            if (nullptr == context)
            {
                return;
            }
            ptr_detach_out(context, node);
        }

        // called by parent node to check if a port linked to this compatible port
        // if it does, it removes itself to it. no need to detach out, this will be called
        // by node, which is triggered by the input port.
        bool detach(IPort* port)
        {
            if (port == context)
            {
                context = nullptr;
                return true;
            }
            return false;
        }

        std::uint32_t score() const noexcept
        {
            if (nullptr == context)
            {
                return 0;
            }
            return ptr_score(context);
        }

        bool is_ready() const
        {
            if (nullptr == context)
            {
                return false;
            }
            return ptr_is_ready(context);
        }

    private:
        INode* parent = nullptr;
        void* context = nullptr;
        void (*ptr_attach_out)(void*, INode*) = nullptr;
        void (*ptr_detach_out)(void*, INode*) = nullptr;
        bool (*ptr_is_ready)(const void*) = nullptr;
        std::uint32_t (*ptr_score)(const void*) = nullptr;
        const TO& (*ptr_value)(const void*) = nullptr;

        template <typename T>
        static void impl_attach_out(void* port, INode* node)
        {
            static_cast<T*>(port)->attach_out(node);
        }

        template <typename T>
        static void impl_detach_out(void* port, INode* node)
        {
            static_cast<T*>(port)->detach_out(node);
        }

        template <typename T>
        static bool impl_is_ready(const void* port)
        {
            return static_cast<const T*>(port)->is_ready();
        }

        template <typename T>
        static std::uint32_t impl_score(const void* port)
        {
            return static_cast<const T*>(port)->score();
        }

        template <typename T>
        static const TO& impl_value(const void* port)
        {
            return static_cast<const T*>(port)->value();
        }

        template <typename Adapter>
            requires(!std::is_base_of_v<IPort, Adapter>)
        explicit Compatible(Adapter* adapter)
            : context(adapter)
            , ptr_attach_out(&impl_attach_out<Adapter>)
            , ptr_detach_out(&impl_detach_out<Adapter>)
            , ptr_is_ready(&impl_is_ready<Adapter>)
            , ptr_score(&impl_score<Adapter>)
            , ptr_value(&impl_value<Adapter>)
        {
        }
    };
}
