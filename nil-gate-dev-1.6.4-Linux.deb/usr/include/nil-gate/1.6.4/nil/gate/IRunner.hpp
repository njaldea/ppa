#pragma once

#include "INode.hpp"

#include <functional>
#include <span>

namespace nil::gate
{
    class Core;

    struct IRunner
    {
        IRunner() = default;
        virtual ~IRunner() noexcept = default;

        IRunner(IRunner&&) noexcept = default;
        IRunner& operator=(IRunner&&) noexcept = default;

        IRunner(const IRunner&) = default;
        IRunner& operator=(const IRunner&) = default;

        /**
         * @param apply_changes - a callable that is intended to apply the changes on the ports.
         *                      - the changes are mainly from Port::set_value.
         * @param nodes - these nodes are alive as long as the Core object is alive.
         */
        virtual void run(std::function<std::span<INode* const>()> apply_changes) = 0;
    };
}
