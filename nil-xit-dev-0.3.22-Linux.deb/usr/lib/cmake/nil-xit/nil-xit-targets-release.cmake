#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nil::xit" for configuration "Release"
set_property(TARGET nil::xit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(nil::xit PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libnil-xit.a"
  )

list(APPEND _cmake_import_check_targets nil::xit )
list(APPEND _cmake_import_check_files_for_nil::xit "${_IMPORT_PREFIX}/lib/libnil-xit.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
