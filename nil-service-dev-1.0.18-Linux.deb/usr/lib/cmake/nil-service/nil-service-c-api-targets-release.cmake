#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nil::service-c-api" for configuration "Release"
set_property(TARGET nil::service-c-api APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(nil::service-c-api PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libnil-service-c-api.so"
  IMPORTED_SONAME_RELEASE "libnil-service-c-api.so"
  )

list(APPEND _cmake_import_check_targets nil::service-c-api )
list(APPEND _cmake_import_check_files_for_nil::service-c-api "${_IMPORT_PREFIX}/lib/libnil-service-c-api.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
