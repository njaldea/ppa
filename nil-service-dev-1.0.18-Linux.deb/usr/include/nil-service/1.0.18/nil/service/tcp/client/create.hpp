#pragma once

#include "../../structs.hpp"

#include <cstdint>
#include <memory>
#include <string>

namespace nil::service::tcp::client
{
    struct Options final
    {
        std::string host;
        std::uint16_t port;
        /**
         * @brief buffer size to use:
         *  - maximum payload size accepted while receiving
         */
        std::uint64_t buffer = 1024;
    };

    std::unique_ptr<IStandaloneService> create(Options options);
}
