#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nil::xit-gtest" for configuration "Release"
set_property(TARGET nil::xit-gtest APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(nil::xit-gtest PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libxit-gtest.a"
  )

list(APPEND _cmake_import_check_targets nil::xit-gtest )
list(APPEND _cmake_import_check_files_for_nil::xit-gtest "${_IMPORT_PREFIX}/lib/libxit-gtest.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
