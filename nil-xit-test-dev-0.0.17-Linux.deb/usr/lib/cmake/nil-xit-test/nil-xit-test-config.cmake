
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

find_package(nil-xit CONFIG REQUIRED)
find_package(nil-gate CONFIG REQUIRED)
include(${CMAKE_CURRENT_LIST_DIR}/nil-xit-test-targets.cmake)

if("ON")
    if("gtest" IN_LIST nil-xit-test_FIND_COMPONENTS)
        find_package(nil-clix CONFIG REQUIRED)
        find_package(GTest CONFIG REQUIRED)
        include(${CMAKE_CURRENT_LIST_DIR}/nil-xit-gtest-targets.cmake)
        include(${CMAKE_CURRENT_LIST_DIR}/nil-xit-gtest.cmake)
        set(nil-xit-test_gtest_FOUND TRUE)
    endif()
endif()

check_required_components(nil-xit-test)
