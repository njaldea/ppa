#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nil::clix" for configuration "Release"
set_property(TARGET nil::clix APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(nil::clix PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libclix.so"
  IMPORTED_SONAME_RELEASE "libclix.so"
  )

list(APPEND _cmake_import_check_targets nil::clix )
list(APPEND _cmake_import_check_files_for_nil::clix "${_IMPORT_PREFIX}/lib/libclix.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
