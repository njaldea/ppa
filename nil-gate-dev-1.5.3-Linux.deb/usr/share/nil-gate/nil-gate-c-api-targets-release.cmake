#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nil::gate-c-api" for configuration "Release"
set_property(TARGET nil::gate-c-api APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(nil::gate-c-api PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libgate-c-api.a"
  )

list(APPEND _cmake_import_check_targets nil::gate-c-api )
list(APPEND _cmake_import_check_files_for_nil::gate-c-api "${_IMPORT_PREFIX}/lib/libgate-c-api.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
